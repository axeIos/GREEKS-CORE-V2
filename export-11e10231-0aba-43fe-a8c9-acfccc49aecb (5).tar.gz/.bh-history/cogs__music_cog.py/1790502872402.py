import discord
from discord import app_commands
from discord.ext import commands
import yt_dlp
import asyncio
from collections import deque
import os

FFMPEG_OPTIONS = {
    'before_options': '-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5',
    'options': '-vn'
}

YDL_BASE = {
    'format': 'bestaudio/best',
    'noplaylist': True,
    'quiet': True,
    'no_warnings': True,
    'source_address': '0.0.0.0',
    'extractor_args': {
        'youtube': {
            'player_client': ['android', 'web']
        }
    }
}

if os.path.exists('cookies.txt'):
    YDL_BASE['cookiefile'] = 'cookies.txt'

YDL_YT = {**YDL_BASE, 'default_search': 'ytsearch'}
YDL_SC = {**YDL_BASE, 'default_search': 'scsearch'}

def search_song(query):
    # 1. Try YouTube
    try:
        print(f"[GREEKS] YT Search: {query}")
        with yt_dlp.YoutubeDL(YDL_YT) as ydl:
            q = query if query.startswith("http") else f"ytsearch:{query}"
            info = ydl.extract_info(q, download=False)
            if 'entries' in info:
                info = info['entries'][0]
            return {'url': info['url'], 'title': info.get('title', 'Unknown')}
    except Exception as e:
        print(f"[GREEKS] YT failed, trying SC: {e}")
        # 2. Fallback SoundCloud - no login needed
        with yt_dlp.YoutubeDL(YDL_SC) as ydl:
            info = ydl.extract_info(f"scsearch:{query}", download=False)
            if 'entries' in info:
                info = info['entries'][0]
            return {'url': info['url'], 'title': info.get('title', 'Unknown') + " [SoundCloud]"}

class Music(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.queues = {}
        self.now_playing = {}

    def get_queue(self, gid):
        if gid not in self.queues:
            self.queues[gid] = deque()
        return self.queues[gid]

    @app_commands.command(name="play", description="Play music - GREEKS")
    async def play(self, interaction: discord.Interaction, query: str):
        if not interaction.user.voice or not interaction.user.voice.channel:
            return await interaction.response.send_message("❌ Join voice first!", ephemeral=True)

        await interaction.response.defer(thinking=True)

        voice = interaction.guild.voice_client
        if not voice:
            voice = await interaction.user.voice.channel.connect()

        try:
            data = await asyncio.to_thread(search_song, query)
        except Exception as e:
            return await interaction.followup.send(f"❌ Error: {e}")

        q = self.get_queue(interaction.guild.id)

        if voice.is_playing() or voice.is_paused():
            q.append((data['url'], data['title']))
            embed = discord.Embed(
                title="GREEKS",
                description=f"Added to queue\n**{data['title']}**\nPos: `{len(q)}`",
                color=0x2b2d31
            )
            return await interaction.followup.send(embed=embed)

        def after_play(err):
            if len(q) > 0:
                nxt_url, nxt_title = q.popleft()
                coro = self.play_next(interaction.guild, nxt_url, nxt_title)
                asyncio.run_coroutine_threadsafe(coro, self.bot.loop)

        voice.play(discord.FFmpegPCMAudio(data['url'], **FFMPEG_OPTIONS), after=after_play)
        self.now_playing[interaction.guild.id] = data['title']

        embed = discord.Embed(
            title="GREEKS",
            description=f"▶️ **{data['title']}**",
            color=0x2b2d31
        )
        await interaction.followup.send(embed=embed)

    async def play_next(self, guild, url, title):
        voice = guild.voice_client
        if not voice:
            return
        q = self.get_queue(guild.id)

        def after_play(err):
            if len(q) > 0:
                nxt_url, nxt_title = q.popleft()
                asyncio.run_coroutine_threadsafe(
                    self.play_next(guild, nxt_url, nxt_title),
                    self.bot.loop
                )

        voice.play(discord.FFmpegPCMAudio(url, **FFMPEG_OPTIONS), after=after_play)
        self.now_playing[guild.id] = title

    @app_commands.command(name="stop", description="Stop music")
    async def stop(self, interaction: discord.Interaction):
        voice = interaction.guild.voice_client
        if voice:
            self.queues.pop(interaction.guild.id, None)
            voice.stop()
            await voice.disconnect()
        await interaction.response.send_message("Stopped", ephemeral=True)

    @app_commands.command(name="skip", description="Skip song")
    async def skip(self, interaction: discord.Interaction):
        voice = interaction.guild.voice_client
        if voice and (voice.is_playing() or voice.is_paused()):
            voice.stop()
            await interaction.response.send_message("Skipped")
        else:
            await interaction.response.send_message("Nothing playing", ephemeral=True)

    @app_commands.command(name="ping", description="Test bot")
    async def ping(self, interaction: discord.Interaction):
        await interaction.response.send_message(f"Pong {round(self.bot.latency*1000)}ms")

async def setup(bot):
    await bot.add_cog(Music(bot))