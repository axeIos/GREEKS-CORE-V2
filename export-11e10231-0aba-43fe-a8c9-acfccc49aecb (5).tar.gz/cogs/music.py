"""
Music - a Components V2 music player cog for discord.py 2.6+.

What it does
    * Plays audio from YouTube through yt-dlp + FFmpeg
    * Shows one clean panel: a container, dividers and emoji buttons (no embeds)
    * Keeps a per-guild queue with loop modes, shuffle and volume
    * Refreshes the panel by itself while a track is playing

Requirements
    Python 3.10+
    pip install -U "discord.py[voice]" yt-dlp
    FFmpeg on the host (set FFMPEG_PATH if it lives somewhere else)

Load it
    await bot.load_extension("cogs.music")
"""

from __future__ import annotations

import asyncio
import os
import random
import time
from collections import deque
from dataclasses import dataclass
from typing import Deque, Dict, Optional

import discord
import yt_dlp
from discord import app_commands, ui
from discord.ext import commands

# Components V2 (ui.LayoutView) only exists in discord.py 2.6+. Without this
# check, an outdated install dies with a cryptic AttributeError while importing
# the panel class, the host restarts the bot, and it crashes again - which
# looks like the bot going online and offline over and over.
if discord.version_info < (2, 6):
    raise RuntimeError(
        "This cog needs discord.py 2.6 or newer for Components V2. "
        'Fix the install with: pip install -U "discord.py[voice]"'
    )

# --------------------------------------------------------------------------- #
# Configuration - everything you may want to tune lives in this block.
# --------------------------------------------------------------------------- #

FFMPEG_PATH = os.getenv("FFMPEG_PATH", "ffmpeg")
COOKIES_FILE = os.getenv("YTDL_COOKIES_FILE", "")  # optional: path to a cookies.txt
DEFAULT_VOLUME = 0.5
IDLE_DISCONNECT_AFTER = 300  # seconds with an empty queue before leaving voice
PANEL_REFRESH_EVERY = 20  # seconds between automatic panel refreshes
QUEUE_PAGE_SIZE = 12  # tracks listed in the queue view

YTDL_OPTIONS: dict = {
    "format": "bestaudio/best",
    "noplaylist": True,
    "quiet": True,
    "no_warnings": True,
    "default_search": "ytsearch",
    "skip_download": True,
    "nocheckcertificate": True,
}
if COOKIES_FILE:
    YTDL_OPTIONS["cookiefile"] = COOKIES_FILE

FFMPEG_BEFORE_OPTIONS = "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5"
FFMPEG_OPTIONS = "-vn"

_ytdl = yt_dlp.YoutubeDL(YTDL_OPTIONS)


# --------------------------------------------------------------------------- #
# Small helpers
# --------------------------------------------------------------------------- #


def format_duration(seconds: Optional[float]) -> str:
    if not seconds:
        return "Live"
    total = int(seconds)
    hours, rest = divmod(total, 3600)
    minutes, secs = divmod(rest, 60)
    if hours:
        return f"{hours}:{minutes:02d}:{secs:02d}"
    return f"{minutes}:{secs:02d}"


def progress_bar(position: float, duration: Optional[float], length: int = 13) -> str:
    if not duration:
        return ""
    ratio = min(max(position / duration, 0.0), 1.0)
    filled = int(ratio * length)
    return "▬" * filled + "🔘" + "▬" * (length - filled)


def _extract_sync(query: str) -> dict:
    info = _ytdl.extract_info(query, download=False)
    if info is None:
        raise RuntimeError("Nothing was found for that search.")
    if "entries" in info:
        entries = [entry for entry in info["entries"] if entry]
        if not entries:
            raise RuntimeError("Nothing was found for that search.")
        info = entries[0]
    return info


async def extract(query: str) -> dict:
    """yt-dlp is blocking, so it runs in a worker thread."""
    return await asyncio.to_thread(_extract_sync, query)


@dataclass(slots=True)
class Track:
    title: str
    stream_url: str
    webpage_url: str
    uploader: str
    thumbnail: Optional[str]
    duration: Optional[int]
    requester_id: int

    @classmethod
    def from_info(cls, info: dict, requester: discord.abc.User) -> "Track":
        stream_url = info.get("url")
        if not stream_url:
            raise RuntimeError("That video cannot be streamed.")
        return cls(
            title=info.get("title") or "Unknown title",
            stream_url=stream_url,
            webpage_url=info.get("webpage_url") or info.get("original_url") or "",
            uploader=info.get("uploader") or info.get("channel") or "Unknown artist",
            thumbnail=info.get("thumbnail"),
            duration=info.get("duration"),
            requester_id=requester.id,
        )

    @property
    def duration_text(self) -> str:
        return format_duration(self.duration)


# --------------------------------------------------------------------------- #
# Playback state (one per guild)
# --------------------------------------------------------------------------- #


class Player:
    def __init__(self, cog: "Music", guild: discord.Guild) -> None:
        self.cog = cog
        self.guild = guild
        self.queue: Deque[Track] = deque()
        self.current: Optional[Track] = None
        self.volume = DEFAULT_VOLUME
        self.loop = "off"  # off | track | queue
        self.panel: Optional[discord.Message] = None
        self._started_at = 0.0
        self._paused_at = 0.0
        self._skipping = False
        self._refresh_task: Optional[asyncio.Task] = None
        self._idle_task: Optional[asyncio.Task] = None

    # ------------------------------------------------------------- state ----
    @property
    def voice(self) -> Optional[discord.VoiceClient]:
        return self.guild.voice_client

    @property
    def is_playing(self) -> bool:
        return self.voice is not None and self.voice.is_playing()

    @property
    def is_paused(self) -> bool:
        return self.voice is not None and self.voice.is_paused()

    @property
    def busy(self) -> bool:
        return self.is_playing or self.is_paused

    def position(self) -> float:
        if self.current is None:
            return 0.0
        end = self._paused_at if self._paused_at else time.monotonic()
        return max(0.0, end - self._started_at)

    # ---------------------------------------------------------- playback ----
    async def play(self, track: Track) -> None:
        voice = self.voice
        if voice is None or not voice.is_connected():
            raise RuntimeError("I am not connected to a voice channel.")
        self.current = track
        self._started_at = time.monotonic()
        self._paused_at = 0.0
        self.cancel_idle()
        source = discord.PCMVolumeTransformer(
            discord.FFmpegPCMAudio(
                track.stream_url,
                executable=FFMPEG_PATH,
                before_options=FFMPEG_BEFORE_OPTIONS,
                options=FFMPEG_OPTIONS,
            ),
            volume=self.volume,
        )
        voice.play(source, after=self._after)
        self.start_refresher()
        await self.update_panel()

    def _after(self, error: Optional[Exception]) -> None:
        """Runs on the audio thread when a track stops."""
        if error:
            print(f"[music] playback error: {error}")
        self.cog.bot.loop.call_soon_threadsafe(
            lambda: asyncio.create_task(self.advance())
        )

    async def advance(self) -> None:
        """Move on to the next track."""
        voice = self.voice
        if voice is None or not voice.is_connected():
            self.current = None
            self.stop_refresher()
            await self.update_panel()
            return

        finished = self.current
        manual = self._skipping
        self._skipping = False

        if finished is not None and not manual:
            if self.loop == "track":
                try:
                    await self.play(finished)
                except Exception as exc:  # e.g. an expired stream URL
                    print(f"[music] could not repeat {finished.title!r}: {exc}")
                    self.stop_refresher()
                    await self.update_panel()
                    self.schedule_idle_disconnect()
                return
            if self.loop == "queue":
                self.queue.append(finished)

        self.current = None
        while self.queue:
            nxt = self.queue.popleft()
            try:
                await self.play(nxt)
            except Exception as exc:  # a single bad track should not kill the queue
                print(f"[music] skipped {nxt.title!r}: {exc}")
                continue
            return

        self.stop_refresher()
        await self.update_panel()
        self.schedule_idle_disconnect()

    async def skip(self) -> None:
        self._skipping = True
        if self.busy:
            self.voice.stop()  # fires _after -> advance()
        else:
            self._skipping = False
            await self.advance()

    async def stop(self) -> None:
        self._skipping = True
        self.queue.clear()
        self.current = None
        self._paused_at = 0.0
        self.cancel_idle()
        self.stop_refresher()
        voice = self.voice
        if voice is not None:
            if voice.is_playing() or voice.is_paused():
                voice.stop()
            if voice.is_connected():
                await voice.disconnect()
        await self.update_panel()

    async def toggle_pause(self) -> bool:
        """Returns True when the track is playing after the call."""
        if self.is_paused:
            self.voice.resume()
            self._started_at += time.monotonic() - self._paused_at
            self._paused_at = 0.0
            return True
        if self.is_playing:
            self._paused_at = time.monotonic()
            self.voice.pause()
            return False
        return False

    def set_volume(self, value: float) -> float:
        self.volume = min(max(value, 0.0), 2.0)
        source = self.voice.source if self.voice is not None else None
        if isinstance(source, discord.PCMVolumeTransformer):
            source.volume = self.volume
        return self.volume

    def cycle_loop(self) -> str:
        order = ("off", "track", "queue")
        self.loop = order[(order.index(self.loop) + 1) % len(order)]
        return self.loop

    def shuffle(self) -> None:
        items = list(self.queue)
        random.shuffle(items)
        self.queue = deque(items)

    def upcoming(self) -> list[Track]:
        return list(self.queue)[:QUEUE_PAGE_SIZE]

    # ------------------------------------------------------------- panel ----
    async def update_panel(self) -> None:
        if self.panel is None:
            return
        try:
            await self.panel.edit(view=self.cog.build_panel(self.guild.id))
        except discord.HTTPException:
            self.panel = None

    def start_refresher(self) -> None:
        self.stop_refresher()
        self._refresh_task = asyncio.create_task(self._refresh())

    async def _refresh(self) -> None:
        try:
            while self.current is not None:
                await asyncio.sleep(PANEL_REFRESH_EVERY)
                if self.current is None:
                    break
                await self.update_panel()
        except asyncio.CancelledError:
            pass

    def stop_refresher(self) -> None:
        if self._refresh_task is not None:
            self._refresh_task.cancel()
            self._refresh_task = None

    def schedule_idle_disconnect(self) -> None:
        self.cancel_idle()
        self._idle_task = asyncio.create_task(self._idle_disconnect())

    async def _idle_disconnect(self) -> None:
        try:
            await asyncio.sleep(IDLE_DISCONNECT_AFTER)
        except asyncio.CancelledError:
            return
        if self.current is None and not self.queue and not self.busy:
            voice = self.voice
            if voice is not None and voice.is_connected():
                await voice.disconnect()
            await self.update_panel()
            self.cog.players.pop(self.guild.id, None)

    def cancel_idle(self) -> None:
        if self._idle_task is not None:
            self._idle_task.cancel()
            self._idle_task = None

    def cleanup(self) -> None:
        self.stop_refresher()
        self.cancel_idle()
        voice = self.voice
        if voice is not None and voice.is_connected():
            voice.stop()


# --------------------------------------------------------------------------- #
# The panel (Components V2)
# --------------------------------------------------------------------------- #


class PlayerPanel(ui.LayoutView):
    """A container, two dividers and two rows of emoji buttons.

    The buttons carry fixed custom ids, so one panel class serves every guild and
    the buttons keep working after a restart. Every handler therefore reads the
    guild from the interaction - never from the instance.
    """

    def __init__(self, cog: "Music", guild_id: int) -> None:
        super().__init__(timeout=None)
        self.cog = cog
        self.guild_id = guild_id
        self.add_item(self._build_container())

    # ---------------------------------------------------------- building ----
    def _build_container(self) -> ui.Container:
        player = self.cog.players.get(self.guild_id)
        track = player.current if player is not None else None
        children: list[ui.Item] = []

        if track is None:
            children.append(
                ui.TextDisplay(
                    "### Nothing is playing\n"
                    "Use **/play** with a song name or a link to start."
                )
            )
        else:
            heading = ui.TextDisplay(f"### [{track.title}]({track.webpage_url})")
            subtitle = ui.TextDisplay(
                f"by {track.uploader}\nrequested by <@{track.requester_id}>"
            )
            if track.thumbnail:
                children.append(
                    ui.Section(
                        heading,
                        subtitle,
                        accessory=ui.Thumbnail(
                            track.thumbnail, description=f"Artwork for {track.title}"
                        ),
                    )
                )
            else:
                children.append(ui.Section(heading, subtitle))

        children.append(ui.Separator())

        if track is not None:
            bar = progress_bar(player.position(), track.duration)
            elapsed = format_duration(player.position())
            if bar:
                children.append(
                    ui.TextDisplay(f"{elapsed}  {bar}  {track.duration_text}")
                )
            else:
                children.append(ui.TextDisplay(f"{elapsed}  •  {track.duration_text}"))
            children.append(
                ui.TextDisplay(
                    f"🔉 **{int(player.volume * 100)}%**  •  "
                    f"🔁 **{player.loop}**  •  "
                    f"📜 **{len(player.queue)}** in queue"
                )
            )
            children.append(ui.Separator())

        children.append(self._transport_row(player))
        children.append(self._extra_row(player))
        return ui.Container(*children)

    def _button(
        self,
        custom_id: str,
        emoji: str,
        handler,
        style: discord.ButtonStyle = discord.ButtonStyle.secondary,
        *,
        disabled: bool = False,
    ) -> ui.Button:
        button = ui.Button(
            style=style, emoji=emoji, custom_id=custom_id, disabled=disabled
        )
        button.callback = handler
        return button

    def _transport_row(self, player: Optional[Player]) -> ui.ActionRow:
        has_track = player is not None and player.current is not None
        paused = bool(has_track and not player.is_playing)
        return ui.ActionRow(
            self._button("music:replay", "⏮", self._on_replay, disabled=not has_track),
            self._button(
                "music:toggle",
                "▶" if paused else "⏸",
                self._on_toggle,
                disabled=not has_track,
            ),
            self._button("music:skip", "⏭", self._on_skip, disabled=not has_track),
            self._button(
                "music:stop",
                "⏹",
                self._on_stop,
                disabled=player is None,
            ),
            self._button("music:loop", "🔁", self._on_loop),
        )

    def _extra_row(self, player: Optional[Player]) -> ui.ActionRow:
        return ui.ActionRow(
            self._button("music:shuffle", "🔀", self._on_shuffle, disabled=player is None),
            self._button("music:volume_down", "🔉", self._on_volume_down),
            self._button("music:volume_up", "🔊", self._on_volume_up),
            self._button("music:queue", "📜", self._on_queue),
        )

    # --------------------------------------------------------- callbacks ----
    def _player(self, interaction: discord.Interaction) -> Optional[Player]:
        return self.cog.players.get(interaction.guild_id)

    async def _sync_panels(self, interaction: discord.Interaction) -> None:
        """Redraw the clicked panel, and the newest panel if it is another one."""
        await interaction.response.edit_message(
            view=self.cog.build_panel(interaction.guild_id)
        )
        player = self._player(interaction)
        if (
            player is not None
            and player.panel is not None
            and player.panel.id != interaction.message.id
        ):
            await player.update_panel()

    async def _not_playing(self, interaction: discord.Interaction) -> None:
        await interaction.response.send_message(
            "Nothing is playing right now.", ephemeral=True
        )

    async def _on_toggle(self, interaction: discord.Interaction) -> None:
        player = self._player(interaction)
        if player is None or player.current is None:
            return await self._not_playing(interaction)
        if player.busy:
            await player.toggle_pause()
        else:
            await player.play(player.current)
        await self._sync_panels(interaction)

    async def _on_replay(self, interaction: discord.Interaction) -> None:
        player = self._player(interaction)
        if player is None or player.current is None:
            return await self._not_playing(interaction)
        await player.play(player.current)
        await self._sync_panels(interaction)

    async def _on_skip(self, interaction: discord.Interaction) -> None:
        player = self._player(interaction)
        if player is None or player.current is None:
            return await self._not_playing(interaction)
        await player.skip()
        await self._sync_panels(interaction)

    async def _on_stop(self, interaction: discord.Interaction) -> None:
        player = self._player(interaction)
        if player is None:
            return await self._not_playing(interaction)
        await player.stop()
        await self._sync_panels(interaction)

    async def _on_loop(self, interaction: discord.Interaction) -> None:
        player = self._player(interaction)
        if player is None:
            return await self._not_playing(interaction)
        player.cycle_loop()
        await self._sync_panels(interaction)

    async def _on_shuffle(self, interaction: discord.Interaction) -> None:
        player = self._player(interaction)
        if player is None or not player.queue:
            return await self._not_playing(interaction)
        player.shuffle()
        await self._sync_panels(interaction)

    async def _on_volume_up(self, interaction: discord.Interaction) -> None:
        player = self._player(interaction)
        if player is None:
            return await self._not_playing(interaction)
        player.set_volume(round(player.volume + 0.1, 2))
        await self._sync_panels(interaction)

    async def _on_volume_down(self, interaction: discord.Interaction) -> None:
        player = self._player(interaction)
        if player is None:
            return await self._not_playing(interaction)
        player.set_volume(round(player.volume - 0.1, 2))
        await self._sync_panels(interaction)

    async def _on_queue(self, interaction: discord.Interaction) -> None:
        player = self._player(interaction)
        if player is None:
            return await self._not_playing(interaction)
        await interaction.response.send_message(
            view=build_queue_view(player), ephemeral=True
        )


def build_queue_view(player: Player) -> ui.LayoutView:
    """The same container style, used for the ephemeral queue list."""
    lines: list[str] = []
    if player.current is not None:
        lines.append(
            f"**Now playing** - [{player.current.title}]({player.current.webpage_url})"
        )
    upcoming = player.upcoming()
    if upcoming:
        lines.append("")
        lines.append("**Up next**")
        for index, track in enumerate(upcoming, start=1):
            lines.append(
                f"`{index}.` [{track.title}]({track.webpage_url}) • {track.duration_text}"
            )
        remaining = len(player.queue) - len(upcoming)
        if remaining > 0:
            lines.append(f"...and **{remaining}** more")
    if not lines:
        lines = ["### The queue is empty", "Use **/play** to add something."]

    view = ui.LayoutView(timeout=120)
    view.add_item(
        ui.Container(
            ui.TextDisplay("\n".join(lines)),
            ui.Separator(),
            ui.TextDisplay(
                f"🔉 **{int(player.volume * 100)}%**  •  "
                f"🔁 **{player.loop}**  •  "
                f"📜 **{len(player.queue)}** queued"
            ),
        )
    )
    return view


# --------------------------------------------------------------------------- #
# The cog
# --------------------------------------------------------------------------- #


class Music(commands.Cog):
    """A Components V2 music player."""

    def __init__(self, bot: commands.Bot) -> None:
        self.bot = bot
        self.players: Dict[int, Player] = {}

    async def cog_load(self) -> None:
        # Register the panel's buttons once so they survive restarts. The guild id
        # here is a placeholder: every handler reads interaction.guild_id instead.
        self.bot.add_view(PlayerPanel(self, 0))

    async def cog_unload(self) -> None:
        for player in list(self.players.values()):
            player.cleanup()
        self.players.clear()

    # ------------------------------------------------------------ helpers ----
    def build_panel(self, guild_id: int) -> PlayerPanel:
        return PlayerPanel(self, guild_id)

    def get_player(self, guild: discord.Guild) -> Player:
        player = self.players.get(guild.id)
        if player is None:
            player = Player(self, guild)
            self.players[guild.id] = player
        return player

    async def connect(self, interaction: discord.Interaction) -> Optional[discord.VoiceClient]:
        """Join the caller's voice channel, or explain why we cannot."""
        state = interaction.user.voice
        channel = state.channel if state is not None else None
        if channel is None:
            await interaction.followup.send(
                "Join a voice channel first, then try again.", ephemeral=True
            )
            return None
        try:
            voice = interaction.guild.voice_client
            if voice is None:
                return await channel.connect(self_deaf=True)
            if voice.channel != channel:
                await voice.move_to(channel)
            return voice
        except discord.Forbidden:
            await interaction.followup.send(
                f"I need the **Connect** and **Speak** permissions in {channel.mention}.",
                ephemeral=True,
            )
            return None

    # ----------------------------------------------------------- commands ----
    @app_commands.command(name="play", description="Play a song or add it to the queue.")
    @app_commands.describe(query="A song name, or a YouTube / SoundCloud link")
    @app_commands.guild_only()
    async def play(self, interaction: discord.Interaction, query: str) -> None:
        await interaction.response.defer()
        if await self.connect(interaction) is None:
            return

        try:
            info = await extract(query)
            track = Track.from_info(info, interaction.user)
        except Exception as exc:
            await interaction.followup.send(f"Could not load that track - {exc}", ephemeral=True)
            return

        player = self.get_player(interaction.guild)
        if player.current is None:
            await player.play(track)
            player.panel = await interaction.followup.send(
                view=self.build_panel(interaction.guild.id), wait=True
            )
        else:
            player.queue.append(track)
            await player.update_panel()
            await interaction.followup.send(
                f"Added **{track.title}** to the queue.", ephemeral=True
            )

    @app_commands.command(name="pause", description="Pause or resume the current track.")
    @app_commands.guild_only()
    async def pause(self, interaction: discord.Interaction) -> None:
        player = self.players.get(interaction.guild_id)
        if player is None or player.current is None:
            await interaction.response.send_message(
                "Nothing is playing right now.", ephemeral=True
            )
            return
        playing = await player.toggle_pause()
        await player.update_panel()
        await interaction.response.send_message(
            "Resumed." if playing else "Paused.", ephemeral=True
        )

    @app_commands.command(name="skip", description="Skip to the next track.")
    @app_commands.guild_only()
    async def skip(self, interaction: discord.Interaction) -> None:
        player = self.players.get(interaction.guild_id)
        if player is None or player.current is None:
            await interaction.response.send_message(
                "Nothing is playing right now.", ephemeral=True
            )
            return
        await interaction.response.send_message("Skipped.", ephemeral=True)
        await player.skip()

    @app_commands.command(name="stop", description="Clear the queue and leave voice.")
    @app_commands.guild_only()
    async def stop(self, interaction: discord.Interaction) -> None:
        player = self.players.get(interaction.guild_id)
        if player is None:
            await interaction.response.send_message(
                "I am not playing anything.", ephemeral=True
            )
            return
        await interaction.response.send_message(
            "Cleared the queue and left the voice channel.", ephemeral=True
        )
        await player.stop()

    @app_commands.command(name="queue", description="See what is playing and what is next.")
    @app_commands.guild_only()
    async def queue(self, interaction: discord.Interaction) -> None:
        player = self.players.get(interaction.guild_id)
        if player is None:
            await interaction.response.send_message(
                "The queue is empty - add a song with **/play**.", ephemeral=True
            )
            return
        await interaction.response.send_message(
            view=build_queue_view(player), ephemeral=True
        )

    @app_commands.command(name="nowplaying", description="Post a fresh player panel here.")
    @app_commands.guild_only()
    async def nowplaying(self, interaction: discord.Interaction) -> None:
        player = self.get_player(interaction.guild)
        player.panel = await interaction.response.send_message(
            view=self.build_panel(interaction.guild.id), wait=True
        )

    @app_commands.command(name="volume", description="Set the playback volume.")
    @app_commands.describe(percent="Volume between 0 and 200")
    @app_commands.guild_only()
    async def volume(
        self, interaction: discord.Interaction, percent: app_commands.Range[int, 0, 200]
    ) -> None:
        player = self.get_player(interaction.guild)
        player.set_volume(percent / 100)
        await player.update_panel()
        await interaction.response.send_message(
            f"Volume set to **{percent}%**.", ephemeral=True
        )

    @app_commands.command(name="loop", description="Choose how the queue repeats.")
    @app_commands.choices(
        mode=[
            app_commands.Choice(name="Off", value="off"),
            app_commands.Choice(name="Repeat the current track", value="track"),
            app_commands.Choice(name="Repeat the whole queue", value="queue"),
        ]
    )
    @app_commands.guild_only()
    async def loop(self, interaction: discord.Interaction, mode: app_commands.Choice[str]) -> None:
        player = self.get_player(interaction.guild)
        player.loop = mode.value
        await player.update_panel()
        await interaction.response.send_message(
            f"Loop mode set to **{mode.value}**.", ephemeral=True
        )

    @app_commands.command(name="shuffle", description="Shuffle everything in the queue.")
    @app_commands.guild_only()
    async def shuffle(self, interaction: discord.Interaction) -> None:
        player = self.players.get(interaction.guild_id)
        if player is None or not player.queue:
            await interaction.response.send_message(
                "There is nothing to shuffle.", ephemeral=True
            )
            return
        player.shuffle()
        await player.update_panel()
        await interaction.response.send_message("Shuffled the queue.", ephemeral=True)

    # ---------------------------------------------------------- listeners ----
    @commands.Cog.listener()
    async def on_voice_state_update(
        self,
        member: discord.Member,
        before: discord.VoiceState,
        after: discord.VoiceState,
    ) -> None:
        if self.bot.user is None or member.id != self.bot.user.id:
            return
        if before.channel is not None and after.channel is None:
            player = self.players.pop(member.guild.id, None)
            if player is not None:
                player.cleanup()


async def setup(bot: commands.Bot) -> None:
    await bot.add_cog(Music(bot))